Setup scripts included: setup_run.bat and setup_run.ps1
Run setup_run.bat in cmd or setup_run.ps1 in PowerShell.
Demo credentials: patient1/1234, dr_aditya/1234
