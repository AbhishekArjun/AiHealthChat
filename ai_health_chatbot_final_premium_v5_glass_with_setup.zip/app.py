import os, sqlite3, datetime, time, random
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

load_dotenv()
OPENAI_KEY = os.environ.get('OPENAI_API_KEY')
MODEL = os.environ.get('OPENAI_MODEL', 'gpt-3.5-turbo')
if OPENAI_KEY:
    import openai
    openai.api_key = OPENAI_KEY

BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, 'database', 'app.db')
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
AVATAR_FOLDER = os.path.join(BASE_DIR, 'static', 'avatars')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(AVATAR_FOLDER, exist_ok=True)

app = Flask(__name__, template_folder='templates', static_folder='static')
app.secret_key = os.environ.get('FLASK_SECRET', 'replace-this-with-secure-random')

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

class User(UserMixin):
    def __init__(self,id,username,is_doctor=False,fullname=None,email=None,avatar=None):
        self.id=id; self.username=username; self.is_doctor=bool(is_doctor)
        self.fullname=fullname; self.email=email; self.avatar=avatar

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

@login_manager.user_loader
def load_user(user_id):
    db = get_db()
    row = db.execute('SELECT * FROM users WHERE id=?',(user_id,)).fetchone()
    if row:
        return User(row['id'],row['username'],row['is_doctor'],row['fullname'],row['email'],row['avatar'])
    return None

def init_db():
    os.makedirs(os.path.join(BASE_DIR,'database'), exist_ok=True)
    db = get_db()
    db.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password_hash TEXT,
        is_doctor INTEGER DEFAULT 0,
        fullname TEXT,
        email TEXT,
        avatar TEXT
    )''')
    db.execute('''CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        doctor_id INTEGER,
        datetime TEXT,
        notes TEXT,
        status TEXT DEFAULT 'scheduled'
    )''')
    db.execute('''CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        role TEXT,
        content TEXT,
        created_at TEXT
    )''')
    db.commit()
    print('Database initialized.')

def create_demo_data():
    db = get_db()
    c = db.execute('SELECT COUNT(*) as c FROM users').fetchone()['c']
    if c == 0:
        print('Creating premium demo data...')
        doctors = [
            ('dr_aditya','Dr. Aditya Rao','Cardiologist',12,'aditya@clinic.com','online'),
            ('dr_sneha','Dr. Sneha Gupta','Dermatologist',8,'sneha@clinic.com','online'),
            ('dr_rahul','Dr. Rahul Mehta','Neurologist',11,'rahul@clinic.com','offline'),
            ('dr_neha','Dr. Neha Sharma','Dentist',9,'neha@clinic.com','online'),
            ('dr_amit','Dr. Amit Kapoor','General Physician',15,'amit@clinic.com','online'),
            ('dr_priya','Dr. Priya Nair','Pediatrician',10,'priya@clinic.com','offline'),
            ('dr_karan','Dr. Karan Singh','Orthopedic',7,'karan@clinic.com','online'),
            ('dr_aisha','Dr. Aisha Verma','Psychiatrist',6,'aisha@clinic.com','online'),
            ('dr_manish','Dr. Manish Tiwari','ENT Specialist',13,'manish@clinic.com','offline'),
            ('dr_meera','Dr. Meera Patel','Gynecologist',9,'meera@clinic.com','online')
        ]
        for uname, fullname, spec, yrs, email, avail in doctors:
            db.execute("INSERT INTO users (username,password_hash,is_doctor,fullname,email,specialization,experience_years,availability) VALUES (?,?,?,?,?,?,?,?)",
                       (uname, generate_password_hash('1234'), 1, fullname, email, spec, yrs, avail))
        # demo patients
        db.execute("INSERT INTO users (username,password_hash,is_doctor,fullname,email) VALUES (?,?,?,?,?)",
                   ('patient1', generate_password_hash('1234'), 0, 'Demo Patient', 'patient1@example.com'))
        db.execute("INSERT INTO users (username,password_hash,is_doctor,fullname,email) VALUES (?,?,?,?,?)",
                   ('patient2', generate_password_hash('1234'), 0, 'Test User', 'testuser@example.com'))
        db.commit()
        # create appointments for variety
        doctor_row = db.execute("SELECT id FROM users WHERE username='dr_aditya'").fetchone()
        patient_row = db.execute("SELECT id FROM users WHERE username='patient1'").fetchone()
        if doctor_row and patient_row:
            doctor_id = doctor_row['id']; patient_id = patient_row['id']
            db.execute("INSERT INTO appointments (user_id,doctor_id,datetime,notes,status) VALUES (?,?,?,?,?)",
                       (patient_id, doctor_id, (datetime.datetime.utcnow()+datetime.timedelta(days=2)).isoformat(), 'Fever follow-up', 'scheduled'))
        # demo messages
        db.execute("INSERT INTO messages (user_id,role,content,created_at) VALUES (?,?,?,?)",
                   (patient_id, 'assistant', 'Hello! This is a demo message from your AI Health Buddy.', datetime.datetime.utcnow().isoformat()))
        db.commit()
        print('Created premium demo doctors and patients (passwords: 1234)')

    db = get_db()
    c = db.execute('SELECT COUNT(*) as c FROM users').fetchone()['c']
    if c == 0:
        print('Creating demo data...')
        db.execute("INSERT INTO users (username,password_hash,is_doctor,fullname,email) VALUES (?,?,?,?,?)",
                   ("dr_smith", generate_password_hash("1234"), 1, "Dr. John Smith", "drsmith@example.com"))
        db.execute("INSERT INTO users (username,password_hash,is_doctor,fullname,email) VALUES (?,?,?,?,?)",
                   ("patient1", generate_password_hash("1234"), 0, "Demo Patient", "patient1@example.com"))
        db.commit()
        doctor_id = db.execute("SELECT id FROM users WHERE username='dr_smith'").fetchone()['id']
        patient_id = db.execute("SELECT id FROM users WHERE username='patient1'").fetchone()['id']
        db.execute("INSERT INTO appointments (user_id,doctor_id,datetime,notes,status) VALUES (?,?,?,?,?)",
                   (patient_id, doctor_id, (datetime.datetime.utcnow()+datetime.timedelta(days=2)).isoformat(), "Demo appointment", "scheduled"))
        db.execute("INSERT INTO messages (user_id,role,content,created_at) VALUES (?,?,?,?)",
                   (patient_id, "assistant", "Hello! This is a demo message from your AI Health Buddy.", datetime.datetime.utcnow().isoformat()))
        db.commit()
        print('Demo accounts created: dr_smith / patient1 with password 1234')

# -- Routes --
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signup', methods=['GET','POST'])
def signup():
    if request.method=='POST':
        username = request.form['username'].strip()
        password = request.form['password']
        fullname = request.form.get('fullname','').strip()
        email = request.form.get('email','').strip()
        is_doctor = 1 if request.form.get('is_doctor')=='on' else 0
        if not username or not password:
            flash('username & password required','error'); return redirect(url_for('signup'))
        db = get_db()
        try:
            db.execute('INSERT INTO users (username,password_hash,is_doctor,fullname,email) VALUES (?,?,?,?,?)',
                       (username, generate_password_hash(password), is_doctor, fullname, email))
            db.commit(); flash('Account created. Please log in.','success'); return redirect(url_for('login'))
        except Exception as e:
            print('signup err',e); flash('Username taken or error','error'); return redirect(url_for('signup'))
    return render_template('signup.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method=='POST':
        username = request.form['username'].strip(); password = request.form['password']
        db = get_db(); row = db.execute('SELECT * FROM users WHERE username=?',(username,)).fetchone()
        if row and check_password_hash(row['password_hash'], password):
            user = User(row['id'],row['username'],row['is_doctor'],row['fullname'],row['email'],row['avatar'])
            login_user(user); flash('Logged in','success')
            return redirect(url_for('dashboard') if not user.is_doctor else url_for('doctor_dashboard'))
        flash('Invalid credentials','error'); return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    try: logout_user()
    except: pass
    flash('Logged out','info'); return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    db = get_db()
    appts = db.execute('SELECT a.*, d.username as doctor_name FROM appointments a LEFT JOIN users d ON d.id=a.doctor_id WHERE a.user_id=? ORDER BY a.datetime DESC',(current_user.id,)).fetchall()
    msgs = db.execute('SELECT * FROM messages WHERE user_id=? ORDER BY created_at DESC LIMIT 12',(current_user.id,)).fetchall()
    return render_template('dashboard_patient.html', appointments=appts, messages=msgs)

@app.route('/doctor_dashboard')
@login_required
def doctor_dashboard():
    if not current_user.is_doctor:
        flash('Access denied','error'); return redirect(url_for('dashboard'))
    db = get_db()
    appts = db.execute('SELECT a.*, u.username as patient_name FROM appointments a LEFT JOIN users u ON u.id=a.user_id WHERE a.doctor_id=? ORDER BY a.datetime DESC',(current_user.id,)).fetchall()
    return render_template('dashboard_doctor.html', appointments=appts)

@app.route('/doctors')
@login_required
def doctors():
    db = get_db(); docs = db.execute('SELECT id,username,fullname,specialization,email,experience_years,availability FROM users WHERE is_doctor=1').fetchall(); return render_template('doctors.html', doctors=docs)

@app.route('/book', methods=['GET','POST'])
@login_required
def book():
    db = get_db()
    if request.method=='POST':
        doctor_id = int(request.form['doctor_id']); dt = request.form['datetime']; notes = request.form.get('notes','').strip()
        db.execute('INSERT INTO appointments (user_id, doctor_id, datetime, notes) VALUES (?,?,?,?)',(current_user.id, doctor_id, dt, notes)); db.commit(); flash('Booked','success'); return redirect(url_for('dashboard'))
    docs = db.execute('SELECT id,username,fullname,specialization,email,experience_years,availability FROM users WHERE is_doctor=1').fetchall()
    return render_template('appointment.html', doctors=docs)

@app.route('/profile', methods=['GET','POST'])
@login_required
def profile():
    if request.method=='POST':
        fullname = request.form.get('fullname','').strip(); email = request.form.get('email','').strip()
        f = request.files.get('avatar'); avatar_filename = None
        if f and f.filename:
            fn = secure_filename(f.filename); avatar_filename = f"avatar_{current_user.id}_{int(time.time())}_{fn}"; f.save(os.path.join(AVATAR_FOLDER, avatar_filename))
        db = get_db(); db.execute('UPDATE users SET fullname=?, email=?, avatar=? WHERE id=?',(fullname,email, avatar_filename or current_user.avatar, current_user.id)); db.commit(); flash('Profile updated','success'); return redirect(url_for('profile'))
    return render_template('profile.html')

@app.route('/chat')
@login_required
def chat():
    return render_template('chat.html')

def offline_reply(message):
    m = message.lower()
    if 'fever' in m: return 'Stay hydrated, monitor temperature, rest. If >38°C consider seeing a doctor.'
    if 'headache' in m: return 'Try rest, hydration, and over-the-counter analgesics; if severe seek care.'
    if 'appointment' in m or 'book' in m: return 'Use the Book Appointment page to select a doctor and time.'
    return 'Thanks for your message — this is an offline demo assistant.'

def call_openai(message):
    try:
        resp = openai.ChatCompletion.create(model=MODEL, messages=[{'role':'system','content':'You are a helpful medical assistant.'},{'role':'user','content':message}], max_tokens=400, temperature=0.6)
        return resp['choices'][0]['message']['content'].strip()
    except Exception as e:
        print('openai err',e); return None

@app.route('/api/chat', methods=['POST'])
@login_required
def api_chat():
    data = request.json or {}; message = data.get('message','').strip()
    if not message: return jsonify({'reply':'Please type something.'})
    time.sleep(0.3 + random.random()*0.4)
    reply = None
    if OPENAI_KEY:
        reply = call_openai(message)
    if not reply:
        reply = offline_reply(message)
    db = get_db(); db.execute('INSERT INTO messages (user_id, role, content, created_at) VALUES (?,?,?,?)',(current_user.id,'user',message, datetime.datetime.utcnow().isoformat())); db.execute('INSERT INTO messages (user_id, role, content, created_at) VALUES (?,?,?,?)',(current_user.id,'assistant',reply, datetime.datetime.utcnow().isoformat())); db.commit()
    return jsonify({'reply':reply, 'timestamp': datetime.datetime.utcnow().isoformat()+'Z'})

@app.route('/api/upload_image', methods=['POST'])
@login_required
def upload_image():
    if 'image' not in request.files: return jsonify({'ok':False,'error':'no file'}),400
    f = request.files['image']; fn = secure_filename(f.filename); save_name = f"{int(time.time())}_{fn}"; f.save(os.path.join(UPLOAD_FOLDER, save_name))
    url = url_for('static', filename=f'uploads/{save_name}'); return jsonify({'ok':True,'url':url,'timestamp':datetime.datetime.utcnow().isoformat()+'Z'})

if __name__=='__main__':
    init_db(); create_demo_data(); app.run(debug=True,port=5000)
