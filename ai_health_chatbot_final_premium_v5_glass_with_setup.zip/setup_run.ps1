# PowerShell setup script. Run: .\setup_run.ps1 (may require ExecutionPolicy adjustment)
python -m venv venv
.\venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Write-Host "Starting app..."
python app.py
