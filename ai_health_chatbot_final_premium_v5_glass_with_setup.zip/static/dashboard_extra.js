window.addEventListener('load', ()=>{
  // animate stat counters
  document.querySelectorAll('.stat-value').forEach(el=>{
    const valText = el.textContent.trim();
    const num = parseFloat(valText) || valText;
    if(typeof num === 'number' && !isNaN(num)){
      let cur = 0; const target = num; const step = Math.max(1, Math.round(target/30));
      const iv = setInterval(()=>{ cur += step; el.textContent = (cur>=target?target:cur); if(cur>=target) clearInterval(iv); }, 18);
      el.classList.add('animated');
    }
  });
  // tips auto scroll
  const tips = document.getElementById('tips');
  if(tips){ let dir = 1; setInterval(()=>{ tips.scrollBy({left: 220*dir, behavior:'smooth'}); dir = (tips.scrollLeft + tips.clientWidth >= tips.scrollWidth) ? -1 : (tips.scrollLeft===0?1:dir); }, 3000); }
});