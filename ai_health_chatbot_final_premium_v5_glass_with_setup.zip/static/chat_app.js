const form = document.getElementById('chatForm');
const input = document.getElementById('inputMsg');
const messagesEl = document.getElementById('messages');
const imageInput = document.getElementById('imageInput');
const micBtn = document.getElementById('micBtn');
let recognition = null;
if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
  const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
  recognition = new Rec();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
}
function appendMessage(text, who='bot', isHtml=false, ts=null){
  const el = document.createElement('div'); el.className = 'msg ' + (who==='user'?'user':'bot');
  el.innerHTML = isHtml? text : escapeHtml(text);
  if(ts) el.innerHTML += `<div style="font-size:11px;color:var(--muted);margin-top:6px">${new Date(ts).toLocaleString()}</div>`;
  messagesEl.appendChild(el); el.scrollIntoView({behavior:'smooth', block:'end'}); return el;
}
function createTyping(){ const el=document.createElement('div'); el.className='msg bot typing'; el.textContent='⋯'; messagesEl.appendChild(el); el.scrollIntoView({behavior:'smooth'}); return el; }
async function postChat(msg){ try{ const res = await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body: JSON.stringify({message:msg})}); return await res.json(); }catch(e){ console.error(e); return {reply:'Server error', timestamp:new Date().toISOString()}; } }
form && form.addEventListener('submit', async (e)=>{ e.preventDefault(); const txt = input.value.trim(); if(!txt) return; appendMessage(txt,'user',false,new Date().toISOString()); input.value=''; const t=createTyping(); const data = await postChat(txt); t.remove(); animateReply(data.reply||'', data.timestamp); });
function animateReply(full, ts){ const el = appendMessage('', 'bot'); let i=0; const delay = 6+Math.random()*6; function step(){ i++; el.innerHTML = escapeHtml(full.slice(0,i)); if(i<full.length) setTimeout(step, delay); else if(ts) el.innerHTML += `<div style="font-size:11px;color:var(--muted);margin-top:6px">${new Date(ts).toLocaleString()}</div>`; el.scrollIntoView({behavior:'smooth'}); } setTimeout(step, 120); }
imageInput && imageInput.addEventListener('change', async (e)=>{ const f = e.target.files[0]; if(!f) return; const url = URL.createObjectURL(f); appendMessage(`<img src="${url}" style="max-width:220px;border-radius:8px"/>`,'user',true,new Date().toISOString()); const fd = new FormData(); fd.append('image', f); try{ const res = await fetch('/api/upload_image',{method:'POST',body:fd}); const j = await res.json(); if(j.ok) appendMessage(`<div>Uploaded:<br/><img src="${j.url}" style="max-width:220px"/></div>`,'bot',true,j.timestamp); else appendMessage('Upload failed','bot'); }catch(err){ appendMessage('Upload error','bot'); } e.target.value=''; });
micBtn && micBtn.addEventListener('click', ()=>{ if(!recognition){ alert('Speech not supported'); return } micBtn.disabled=true; micBtn.textContent='🎙️...'; recognition.start(); });
if(recognition){ recognition.onresult = (ev)=>{ input.value = ev.results[0][0].transcript; input.focus(); }; recognition.onend = ()=>{ micBtn.disabled=false; micBtn.textContent='🎤'; }; recognition.onerror = (e)=>{ console.error(e); micBtn.disabled=false; micBtn.textContent='🎤'; }; }
function escapeHtml(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
